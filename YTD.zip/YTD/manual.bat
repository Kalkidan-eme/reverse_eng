ECHO OFF
set str=%*
set str=%str:~1,-1%
%str%
PAUSE
